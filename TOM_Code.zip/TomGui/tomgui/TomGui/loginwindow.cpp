#include "loginwindow.h"
#include "ui_loginwindow.h"

#include <QMessageBox>

LoginWindow::LoginWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::LoginWindow)
{
    ui->setupUi(this);
}

LoginWindow::~LoginWindow()
{
    delete ui;
}

void LoginWindow::on_pushButton_Login_clicked()
{
    QString username = ui->lineEdit_Username->text();
    QString password = ui->lineEdit_Password->text();

    if(username == "test" && password == "test"){
        //QMessageBox::information(this, "Login", "Username and password is correct");
        hide();
        menuWindow = new MenuWindow(this);
        menuWindow->show();
    }
    else{
        QMessageBox::warning(this, "Login", "Username and password is not correct");
    }
}

#ifndef MENUWINDOW_H
#define MENUWINDOW_H

#include <QDialog>
#include "trainingwindow.h"

namespace Ui {
class MenuWindow;
}

class MenuWindow : public QDialog
{
    Q_OBJECT

public:
    explicit MenuWindow(QWidget *parent = 0);
    ~MenuWindow();

private slots:
    void on_pushButtonTraining_clicked();

private:
    Ui::MenuWindow *ui;
    TrainingWindow *trainingWindow;
};

#endif // MENUWINDOW_H

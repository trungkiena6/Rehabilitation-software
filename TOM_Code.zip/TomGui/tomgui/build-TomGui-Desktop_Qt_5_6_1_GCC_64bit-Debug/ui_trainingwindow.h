/********************************************************************************
** Form generated from reading UI file 'trainingwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TRAININGWINDOW_H
#define UI_TRAININGWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_TrainingWindow
{
public:
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QDialog *TrainingWindow)
    {
        if (TrainingWindow->objectName().isEmpty())
            TrainingWindow->setObjectName(QStringLiteral("TrainingWindow"));
        TrainingWindow->resize(400, 300);
        pushButton = new QPushButton(TrainingWindow);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(90, 60, 221, 71));
        pushButton_2 = new QPushButton(TrainingWindow);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(90, 170, 221, 71));

        retranslateUi(TrainingWindow);

        QMetaObject::connectSlotsByName(TrainingWindow);
    } // setupUi

    void retranslateUi(QDialog *TrainingWindow)
    {
        TrainingWindow->setWindowTitle(QApplication::translate("TrainingWindow", "Dialog", 0));
        pushButton->setText(QApplication::translate("TrainingWindow", "ACTIVE", 0));
        pushButton_2->setText(QApplication::translate("TrainingWindow", "PASSIVE", 0));
    } // retranslateUi

};

namespace Ui {
    class TrainingWindow: public Ui_TrainingWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TRAININGWINDOW_H

/********************************************************************************
** Form generated from reading UI file 'menuwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MENUWINDOW_H
#define UI_MENUWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_MenuWindow
{
public:
    QPushButton *pushButtonTraining;
    QPushButton *pushButtonGame;
    QPushButton *pushButtonReport;

    void setupUi(QDialog *MenuWindow)
    {
        if (MenuWindow->objectName().isEmpty())
            MenuWindow->setObjectName(QStringLiteral("MenuWindow"));
        MenuWindow->resize(400, 300);
        pushButtonTraining = new QPushButton(MenuWindow);
        pushButtonTraining->setObjectName(QStringLiteral("pushButtonTraining"));
        pushButtonTraining->setGeometry(QRect(110, 30, 161, 51));
        pushButtonGame = new QPushButton(MenuWindow);
        pushButtonGame->setObjectName(QStringLiteral("pushButtonGame"));
        pushButtonGame->setGeometry(QRect(110, 120, 161, 51));
        pushButtonReport = new QPushButton(MenuWindow);
        pushButtonReport->setObjectName(QStringLiteral("pushButtonReport"));
        pushButtonReport->setGeometry(QRect(110, 200, 161, 51));

        retranslateUi(MenuWindow);

        QMetaObject::connectSlotsByName(MenuWindow);
    } // setupUi

    void retranslateUi(QDialog *MenuWindow)
    {
        MenuWindow->setWindowTitle(QApplication::translate("MenuWindow", "Dialog", 0));
        pushButtonTraining->setText(QApplication::translate("MenuWindow", "GAME", 0));
        pushButtonGame->setText(QApplication::translate("MenuWindow", "SETTING ROM", 0));
        pushButtonReport->setText(QApplication::translate("MenuWindow", "REPORT", 0));
    } // retranslateUi

};

namespace Ui {
    class MenuWindow: public Ui_MenuWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MENUWINDOW_H

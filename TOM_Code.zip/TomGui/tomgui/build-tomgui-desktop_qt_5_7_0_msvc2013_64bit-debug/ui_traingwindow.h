/********************************************************************************
** Form generated from reading UI file 'traingwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TRAINGWINDOW_H
#define UI_TRAINGWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_TraingWindow
{
public:
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QDialog *TraingWindow)
    {
        if (TraingWindow->objectName().isEmpty())
            TraingWindow->setObjectName(QStringLiteral("TraingWindow"));
        TraingWindow->resize(400, 300);
        pushButton = new QPushButton(TraingWindow);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(100, 40, 201, 91));
        pushButton_2 = new QPushButton(TraingWindow);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(100, 160, 201, 91));

        retranslateUi(TraingWindow);

        QMetaObject::connectSlotsByName(TraingWindow);
    } // setupUi

    void retranslateUi(QDialog *TraingWindow)
    {
        TraingWindow->setWindowTitle(QApplication::translate("TraingWindow", "Dialog", 0));
        pushButton->setText(QApplication::translate("TraingWindow", "ACTIVE", 0));
        pushButton_2->setText(QApplication::translate("TraingWindow", "PASSIVE", 0));
    } // retranslateUi

};

namespace Ui {
    class TraingWindow: public Ui_TraingWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TRAINGWINDOW_H
